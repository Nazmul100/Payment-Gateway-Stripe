<?php
require ('config.php');
if (isset($_POST['stripeToken'])) {


    \Stripe\Stripe::setVerifySslCerts(false);
//echo '<pre>';
//print_r($_POST);

    $token = $_POST['stripeToken'];
    $data = \Stripe\Charge::create(array(
        "amount" => "5000",

        "currency" => "USD",
        "description" => "I am ",
        "source" => $token,
    ));

echo '<pre>';
var_dump($data);

}
?>
