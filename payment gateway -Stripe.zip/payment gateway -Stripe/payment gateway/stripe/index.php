<?php
require ('config.php');
?>
<form action="submit.php" method="POST">

<script
src="https://checkout.stripe.com/checkout.js" class="stripe-button"
data-key="<?php echo $publishableKey?>"
data-amount="2"

data-name="Nazmul Hossain"
data-description="I am a students"
data-image="https://png.pngtree.com/element_pic/00/16/07/06577d261edb9ec.jpg"
data-currency="USD"

<!--data-email="nazmulhudanaim98@gmail.com"-->


>

</script>


</form>




