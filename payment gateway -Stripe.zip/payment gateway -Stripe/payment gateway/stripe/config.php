<?php
require ('stripe-php-master/init.php');
$publishableKey=
    "pk_test_51K4IlWHHiGg3IzZO5TcWForTsuHq8nyeApqdgTRL3Mmo1dnTuBbZ4fGxN4Mii7pYqaGvjItLbiO9SdG7t8gJD47Y00d4fSdK1E";
$secretKey=
    "sk_test_51K4IlWHHiGg3IzZOHCaKZ2l91qAga1Dbt3865LHJr9QOR0cpmA7s7MRe8TdCQjeoVU1CeGgF0uQ0LS8K7FyLDB0000BzYAmr9O";
\Stripe\Stripe::setApiKey ($secretKey);
?>